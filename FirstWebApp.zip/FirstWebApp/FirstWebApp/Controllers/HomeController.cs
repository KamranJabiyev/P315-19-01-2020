﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstWebApp.Controllers
{
    public class HomeController:Controller
    {
        public IActionResult Index()
        {
            //ViewResult view = new ViewResult();
            //view.ViewName = "Index";
            return View();
            //return Content("Salam");
            //return Json(new {
            //    name="Fikret",
            //    surname="Javadov"
            //});
        }

        public string About()
        {
            return "About page";
        }
    }
}
